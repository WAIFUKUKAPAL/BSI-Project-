const navItem = document.querySelectorAll (".menu > .linav")

navItem.forEach((nav) => {
   const menuList = nav.querySelector(".menu-list");
   if (menuList)
   nav.addEventListener("mouseenter",() => {
         menuList.classList.add("navbar-expand");
      });
   nav.addEventListener("mouseleave",() => {
         menuList.classList.remove("navbar-expand");
      });
})


const menuToggle = document.querySelector (".navbar-toggle");


menuToggle.addEventListener("click" ,() => {
   document.querySelector(".menu").classList.toggle("navbar-expand");
   
   document.querySelector(".button").classList.toggle("navbar-expand");
   
   document.querySelector(".navbar-toggle").classList.toggle("navbar-expand");
})

